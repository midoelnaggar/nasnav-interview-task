(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 395:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "Footer_footer__oaUOW",
	"top": "Footer_top__Js8_G",
	"start": "Footer_start__129ai",
	"end": "Footer_end__CN_55",
	"title": "Footer_title__6YbM8",
	"inputContainer": "Footer_inputContainer__5cS6A",
	"links": "Footer_links__P_15J",
	"bottom": "Footer_bottom__oDlEk",
	"center": "Footer_center__SlsY1"
};


/***/ }),

/***/ 917:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Header_header__R_kkv",
	"top": "Header_top__24pMT",
	"logo": "Header_logo__vc15F",
	"ad": "Header_ad__aS0iC",
	"links": "Header_links__Y2Z7h",
	"center": "Header_center__mRFwV",
	"searchInputContainer": "Header_searchInputContainer__PQ61T",
	"vendorLogoContainer": "Header_vendorLogoContainer__AJP9X",
	"cartWishlistLogin": "Header_cartWishlistLogin__m3QTX",
	"bottom": "Header_bottom__UCJi8"
};


/***/ }),

/***/ 606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/styles/Header.module.scss
var Header_module = __webpack_require__(917);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./src/components/Header.js



const Header = ({ cart , openCart , setOpenCart  })=>{
    const [cartCount, setCartCount] = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        const settingCount = async ()=>{
            let count = 0;
            for(let i = 0; i < cart.length; i++){
                count += await cart[i].qty;
            }
            setCartCount(count);
        };
        settingCount();
    }, [
        cart
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: (Header_module_default()).header,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Header_module_default()).top,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/headerMenu.svg",
                            alt: "Menu"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: (Header_module_default()).logo,
                            src: "/images/headerYeshteryLogo.svg",
                            alt: "Logo"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).ad,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/headerArrowLeft.svg",
                                alt: "headerArrowLeft"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    "Valentine’s Day Offers! Buy Two Get One Free ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "",
                                        children: "Shop Now"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/headerArrowRight.svg",
                                alt: "headerArrowRight"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).links,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerPhone.svg",
                                        alt: "Phone"
                                    }),
                                    " Contact Us"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerTrolley.svg",
                                        alt: "Trolley"
                                    }),
                                    " Track Order"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerPin.svg",
                                        alt: "Pin"
                                    }),
                                    " Find A Store"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Header_module_default()).center,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).searchInputContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                placeholder: "Search"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/headerSearch.svg",
                                alt: "headerSearch"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).vendorLogoContainer,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/static/adidas.svg",
                            alt: "adidas"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).cartWishlistLogin,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                onClick: ()=>setOpenCart(!openCart),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerCart.svg",
                                        alt: "headerCart"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: cartCount
                                    }),
                                    "Cart"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerHeart.svg",
                                        alt: "headerHeart"
                                    }),
                                    "Wishlist"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/headerUser.svg",
                                        alt: "headerUser"
                                    }),
                                    "Login"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Header_module_default()).bottom,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Men"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Women"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Unisex"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Kids"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Best Sellers"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "New Arrivals"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "",
                        children: "Offers"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Header = (Header);

// EXTERNAL MODULE: ./src/styles/Footer.module.scss
var Footer_module = __webpack_require__(395);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./src/components/Footer.js


const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (Footer_module_default()).footer,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).top,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).start,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/footerLogo.svg",
                                alt: "footerLogo"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed dia m nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    " Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).end,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Footer_module_default()).title,
                                children: "Subscribe to our newsletter"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).inputContainer,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        placeholder: "Enter Your Mail"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        children: [
                                            "Subscribe",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/images/footerSubscribe.svg",
                                                alt: "footerSubscribe"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Footer_module_default()).links,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).start,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "About Us"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Contact Us"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Track Order"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Terms & Conditions"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Privacy Policy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Sell With Us"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Shipping And Returns"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (Footer_module_default()).end,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/images/fb.svg",
                                                        alt: "fb"
                                                    }),
                                                    " /YESHTERY"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/images/li.svg",
                                                        alt: "li"
                                                    }),
                                                    " /YESHTERY"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/images/ig.svg",
                                                        alt: "ig"
                                                    }),
                                                    " /YESHTERY"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "",
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        src: "/images/tw.svg",
                                                        alt: "tw"
                                                    }),
                                                    " /YESHTERY"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).bottom,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Footer_module_default()).start,
                        children: "\xa9 2021 yeshtery, all rights reserved."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).center,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/cod.png",
                                alt: "cod"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/visa.png",
                                alt: "visa"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/mc.png",
                                alt: "mc"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default()).end,
                        children: [
                            "Powered By ",
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/nasnav.png",
                                alt: "nasnav"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./src/styles/globals.scss
var globals = __webpack_require__(961);
;// CONCATENATED MODULE: ./src/pages/_app.js


const Cart = /*#__PURE__*/ (0,external_react_.lazy)(()=>__webpack_require__.e(/* import() */ 314).then(__webpack_require__.bind(__webpack_require__, 314)));



function App({ Component , pageProps  }) {
    const [cart, setCart] = (0,external_react_.useState)([]);
    const [openCart, setOpenCart] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_Header, {
                cart: cart,
                openCart: openCart,
                setOpenCart: setOpenCart
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                cart: cart,
                setCart: setCart,
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Cart, {
                    cart: cart,
                    setCart: setCart,
                    openCart: openCart,
                    setOpenCart: setOpenCart
                })
            })
        ]
    });
}


/***/ }),

/***/ 961:
/***/ (() => {



/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(606));
module.exports = __webpack_exports__;

})();