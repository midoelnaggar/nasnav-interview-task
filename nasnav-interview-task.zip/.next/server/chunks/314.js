exports.id = 314;
exports.ids = [314];
exports.modules = {

/***/ 805:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Cart_main__hejqX",
	"backdrop": "Cart_backdrop__3vlio",
	"cart": "Cart_cart__eikop",
	"title": "Cart_title__MtOLO",
	"subtitle": "Cart_subtitle__9jjjA",
	"items": "Cart_items__asWQy",
	"card": "Cart_card__VGr4b",
	"imageContainer": "Cart_imageContainer__tHyDC",
	"details": "Cart_details__Ws96h",
	"name": "Cart_name__FHmKo",
	"qty": "Cart_qty__vQDX7",
	"priceAndRemove": "Cart_priceAndRemove__rmaGO",
	"price": "Cart_price__4vHUo",
	"remove": "Cart_remove__di2q1",
	"total": "Cart_total__aC7pO",
	"closeCart": "Cart_closeCart__nhmlD",
	"emptyCart": "Cart_emptyCart__Nz7na"
};


/***/ }),

/***/ 314:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(805);
/* harmony import */ var _styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function Cart({ cart , setCart , openCart , setOpenCart  }) {
    const [cartTotal, setCartTotal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const settingTotal = async ()=>{
            let total = 0;
            for(let i = 0; i < cart.length; i++){
                const itemTotal = await cart[i].price * cart[i].qty;
                total += await itemTotal;
            }
            setCartTotal(total);
        };
        settingTotal();
    }, [
        cart
    ]);
    const handleRemoveItem = async ()=>{
        let otherProducts = await cart.filter((e)=>{
            return e.id != "1001";
        });
        setCart([
            ...otherProducts
        ]);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: openCart && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().main),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>setOpenCart(false),
                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().backdrop)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().cart),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().title),
                            children: "My Cart"
                        }),
                        cart?.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().subtitle),
                                    children: "Cart Summary"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().items),
                                    children: cart?.map((item, index)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().card),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().imageContainer),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: item?.image,
                                                        alt: "item"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().details),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().name),
                                                            children: item?.name
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().qty),
                                                            children: [
                                                                "Quantity: ",
                                                                item?.qty
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().priceAndRemove),
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().price),
                                                                    children: [
                                                                        item?.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                                                        " "
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    onClick: handleRemoveItem,
                                                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().remove),
                                                                    children: "Remove"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index);
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().total),
                                    children: [
                                        "Total:",
                                        " ",
                                        cartTotal.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                        " ",
                                        "LE"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setOpenCart(false),
                                    className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().closeCart),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/images/closeCart.svg",
                                        alt: "closeCart"
                                    })
                                })
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_Cart_module_scss__WEBPACK_IMPORTED_MODULE_2___default().emptyCart),
                                children: "Empty Cart"
                            })
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cart);


/***/ })

};
;