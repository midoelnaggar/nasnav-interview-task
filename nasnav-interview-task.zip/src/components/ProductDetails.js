import styles from "@/styles/ProductDetails.module.scss";


function ProductDetails() {
    return (
        <div className={styles.main}>
        
        </div>
    );
}

export default ProductDetails;